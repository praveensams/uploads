var express = require("express");
var app = express();
var httpProxy = require('http-proxy'),
  session = require('express-session'),
  request = require('request-promise'),
  body = require('body-parser'),
  serveIndex = require('serve-index');
var apiProxy = httpProxy.createProxyServer();
//var zabbix = 'http://139.217.15.48/',
  //jenkins = 'http://52.169.75.89:8080/',
  //nexus = 'http://petdevops.pearson.com:9000/';

var passport = require('passport'),
   LocalStrategy = require('passport-local').Strategy;


//app.all("/zabbix/*", function (req, res) {
//   console.log('redirecting to zabbix');
//   apiProxy.web(req, res, { target: zabbix });
// });

// app.all("/jenkins/*", function (req, res) {
//   console.log('redirecting to jenkins');
//   apiProxy.web(req, res, { target: jenkins });
// });
// app.all("/nexus/*", function (req, res) {
//   console.log('redirecting to nexus');
//   apiProxy.web(req, res, { target: nexus });
// });




app.post('/deploy/', function(req, res) {
  var spawn = require('child_process').spawn,
      deploy = spawn('sh', ['./webhook.sh']);
  deploy.stdout.on('data', function(data){
    console.log(''+data);
  });
  deploy.on('close',function(code){
    console.log('child process exited' +code);
  });
  res.status(200)
    .json({message:'webhook successful'})
});

app.use(body.urlencoded({ extended: true }));
app.use(body.json());
//Store all JS and CSS in Scripts folder.



app.use(session({
  name:'onedevops',
  saveUninitialized: true,
  resave: true,
  secret: 'madan',
  cookie: {
    maxAge: 24 * (60 * 60 * 1000),
    httpOnly: true,
    secure: false
  },
  key: 'sessionId',
}));

app.use(passport.initialize());
app.use(passport.session());


passport.serializeUser(function (user, done) {
  return done(null, user);
});

passport.deserializeUser(function (user, done) {
  return done(null, user);
});

passport.use('local', new LocalStrategy({
  usernameField: 'username',
  passwordField: 'password',
  passReqToCallback: true
},
  function (req, username, password, done) {
    request('https://identity-internal.pearson.com/auth/json/pearson/authenticate',
      {
        method: 'POST',
        headers: {
          'Accept-API-Version': 'resource=2.0, protocol=1.0',
          'X-OpenAM-Username': username,
          'X-OpenAm-Password': password
        }
      })
      .then(function (response) {

        try {
          response = JSON.parse(response);
          if (response.tokenId) {
            request('https://identity-internal.pearson.com/auth/json/pearson/users/' + username, {
              method: 'GET',
              headers: {
                'pearsonssosession': response.tokenId
              }
            })
              .then(function (userResponse) {
                try {
                  var userObject = JSON.parse(userResponse);

                  return done(null, userObject);
                }
                catch (e) {
                   return done(null, false);
                }
              })
          }
          else {
            return done(null, false);
          }
        }
        catch (e) {
          return done(null, false);
        }
      }, function (err) {
        return done(null, false);
      });
  }
));

app.get('*.html',function(req, res ,next){
  if(req.isAuthenticated()){
    if(req.url.indexOf('login.html') > -1){
         res.redirect('/index.html');
    }
    else{
       next();
    }
  }
  else{
    console.log(req.url.indexOf('login.html'));
      if(req.url.indexOf('login.html') > -1){
         next();
      }
      else{
         res.redirect('/login.html');
      }
  }
});

app.get('/', function (req, res) {
  console.log('>>> NEW AUTHENTICATION <<<');
  console.log(req.isAuthenticated());
  if(req.isAuthenticated()){
      res.redirect('/index.html');
  }
  else{
      res.redirect('/login.html');
  }
  
  //It will find and locate index.html from View or Scripts
});

app.get('/login', function (req, res) {
  res.sendFile(__dirname+'/View/login.html');
  //It will find and locate index.html from View or Scripts
});

app.get('/index', function (req, res) {
  res.sendFile(__dirname+'/View/index.html');
  //It will find and locate index.html from View or Scripts
});

app.use('/autoscripts', serveIndex('scripts', {'icons': true}));

app.use(express.static(__dirname + '/View'));
//Store all HTML files in view folder.
app.use(express.static(__dirname + '/Script'));
app.use('/autoscripts', express.static(__dirname + '/scripts'));


app.post('/login',
  passport.authenticate('local', {
    successRedirect: '/index.html',
    failureRedirect: '/login.html'
  })
);



app.listen(3000);

console.log("Running at Port 5000");