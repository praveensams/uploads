#! /bin/bash

SRC_DIR=./scripts
giturl=ssh://git@bitbucket.pearson.com/pebs/buildscripts.git

if [ ! -d "$SRC_DIR" ]; then 
    mkdir $SRC_DIR;
    cd $SRC_DIR 
    git clone $giturl .
else 
    cd $SRC_DIR
    git pull
fi