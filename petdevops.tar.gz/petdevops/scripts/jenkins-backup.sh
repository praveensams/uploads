#!/bin/bash
set -e

jenkins_home=/var/lib/jenkins
jenkins_job=$jenkins_home/jobs
date=$(date +%Y-%m-%d%H-%M-%S)
backup=/var/lib/cicdassets/jenkins-$date
archive_backup=/var/lib/cicdassets/jenkins_backup/
archive=jenkins-backup-$date.tar.gz

#create desired directories

if [[ ! -e $archive_backup ]]; then
mkdir $archive_backup
fi

mkdir $backup

#switch to jenkins' home directory

# Backup All the xml file in the root directory 

cp "$jenkins_home/"*.xml $backup

# Backup Plugins folder if exits 

if [ "$(ls -A $jenkins_home/plugins/)" ]; then
  	mkdir -p $backup/plugins
	cp "$jenkins_home/plugins/"*.[hj]pi "$backup/plugins"
fi

# Backup secrets folder if exits 

if [ "$(ls -A $jenkins_home/secrets/)" ]; then
  	mkdir -p $backup/secrets
	cp -R "$jenkins_home/secrets/"* "$backup/secrets"
fi

# Backup slave nodes folder if exits 

if [ "$(ls -A $jenkins_home/nodes/)" ]; then
  	mkdir -p $backup/nodes
	cp -R "$jenkins_home/nodes/"* "$backup/nodes"
fi

# Backup Jobs folder if exits 

if [ "$(ls -A $jenkins_job)" ]; then
  	cd $jenkins_job
	mkdir -p $backup/jobs
	cp --parent ./*/config.xml "$backup/jobs"
fi

# Compress all the backup 
cd $backup

tar -zcvf $archive *

mv $archive $archive_backup

cd -

rm -rf $backup

echo "Backup Job completed Succesufully"
