#! /bin/bash

loc=/usr/src/app
giturl=ssh://git@bitbucket.pearson.com/pebs/devops.git

if test ! -e $loc/package.json ; then
    cd $loc
    git clone $giturl .
    npm install
    npm start
else
    cd $loc
    git pull
    npm install
    npm start
fi